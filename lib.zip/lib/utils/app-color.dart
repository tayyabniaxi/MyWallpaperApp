

import 'package:flutter/material.dart';

class AppColor{


  static const primaryColor=Color(0xFF7B39FD);
  static const categoryLightThemeColorUnselect=Color(0xFFE5D7FF);
  static const categoryLightThemeColorselect=Color(0xFF7B39FD);
  static const categorydarkThemeColorUnselect=Color(0xFF4C3D90);
  static const categorydarkThemeColorselect=Color(0xFF7B39FD);
  static const lightunSelect=Color(0xFFE5D7FF);

  static const lightThemesubCategoryimageCountContainer=Color(0xffF3F3F3);
}